using Microsoft.EntityFrameworkCore;
using AgenciaDeViajes.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using AgenciaDeViajes.Services; // Para WeatherService
using AgenciaDeViajes.ML;        // Para el servicio ML de Sentimientos
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace AgenciaDeViajes
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Agregar servicios MVC
            builder.Services.AddControllersWithViews();

            // Configuración de la cadena de conexión (usa Render o local)
            var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseNpgsql(connectionString));

            // Habilitar autenticación con cookies
            builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options => {
                    options.LoginPath = "/Login/Index";
                });

            builder.Services.AddAuthorization();

            // === REGISTRO DEL SERVICIO DE CLIMA ===
            builder.Services.AddHttpClient<WeatherService>();

            // === HABILITAR SESSION ===
            builder.Services.AddSession();

            // === REGISTRO DEL SERVICIO ML ===
            builder.Services.AddSingleton<SentimientoPredictionService>(serviceProvider =>
            {
                var env = serviceProvider.GetRequiredService<IWebHostEnvironment>();
                var modeloPath = Path.Combine(env.ContentRootPath, "ML", "modelo_tours.zip");
                return new SentimientoPredictionService(modeloPath);
            });

            var app = builder.Build();

            // Ejecutar migraciones automáticamente en producción
            using (var scope = app.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                db.Database.Migrate(); // Esto crea/modifica tablas en Render
            }

            // Configuración del pipeline HTTP
            if (app.Environment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseSession();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            // Rutas explícitas
            app.MapControllerRoute(
                name: "destinosLista",
                pattern: "ListaTours/Destination",
                defaults: new { controller = "ListaTours", action = "Destination" }
            );

            app.MapControllerRoute(
                name: "detallesDestinoSeo",
                pattern: "ListaTours/{nombreSeo}",
                defaults: new { controller = "ListaTours", action = "Details" }
            );

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}"
            );

            app.Run();
        }
    }
}
