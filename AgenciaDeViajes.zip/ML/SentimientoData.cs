namespace AgenciaDeViajes.ML
{
    public class SentimientoData
    {
        // El texto que será analizado por ML.NET
        public string Texto { get; set; }
    }
}
